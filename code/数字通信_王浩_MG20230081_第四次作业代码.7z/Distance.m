function dist =  Distance(X,Y)
dist = sqrt(sum((X - Y).^2));