AWGN
Rayleigh
Rician